import 'package:flutter/material.dart';

class VerificationRecord {
  final String verificationId;
  final String employeeId;
  final String adminId;
  final String status; // 'pending', 'approved', 'rejected', 'under_review'
  final DateTime createdAt;
  final DateTime? updatedAt;
  final String? remarks;
  final List<DocumentUpload> documents;

  VerificationRecord({
    required this.verificationId,
    required this.employeeId,
    required this.adminId,
    required this.status,
    required this.createdAt,
    this.updatedAt,
    this.remarks,
    required this.documents,
  });
}

class DocumentUpload {
  final String uploadId;
  final String requestId;
  final String documentType; // 'id_copy', 'employment_proof', 'selfie'
  final String filePath;
  final String fileName;
  final String fileSize;
  final DateTime uploadDate;
  final String status; // 'uploaded', 'verified', 'rejected'
  final String? verificationNotes;

  DocumentUpload({
    required this.uploadId,
    required this.requestId,
    required this.documentType,
    required this.filePath,
    required this.fileName,
    required this.fileSize,
    required this.uploadDate,
    this.status = 'uploaded',
    this.verificationNotes,
  });

  String get documentTypeName {
    switch (documentType) {
      case 'id_copy':
        return 'ID Document';
      case 'employment_proof':
        return 'Employment Proof';
      case 'selfie':
        return 'Selfie Verification';
      default:
        return 'Document';
    }
  }

  IconData get documentIcon {
    switch (documentType) {
      case 'id_copy':
        return Icons.credit_card;
      case 'employment_proof':
        return Icons.work;
      case 'selfie':
        return Icons.face;
      default:
        return Icons.description;
    }
  }
}
