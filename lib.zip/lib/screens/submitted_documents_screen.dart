// screens/submitted_documents_screen.dart
import 'package:flutter/material.dart';
import 'package:group_i/models/verification_model.dart';
import 'package:group_i/services/auth_service.dart';
import 'package:group_i/screens/document_viewer_screen.dart';

class SubmittedDocumentsScreen extends StatefulWidget {
  final String? employeeId;

  const SubmittedDocumentsScreen({super.key, this.employeeId});

  @override
  State<SubmittedDocumentsScreen> createState() =>
      _SubmittedDocumentsScreenState();
}

class _SubmittedDocumentsScreenState extends State<SubmittedDocumentsScreen> {
  final AuthService _authService = AuthService();
  late Future<List<DocumentUpload>> _documentsFuture;
  List<DocumentUpload> _documents = [];

  @override
  void initState() {
    super.initState();
    _loadDocuments();
  }

  void _loadDocuments() {
    // If employeeId is provided (admin view), fetch for that employee.
    // Otherwise, fetch for the currently logged-in user.
    final targetEmployeeId =
        widget.employeeId ?? _authService.currentUser?.userID;

    if (targetEmployeeId != null) {
      _documentsFuture = _authService.getDocumentsForEmployee(targetEmployeeId);
    } else {
      // Handle case where no user is logged in and no ID is passed
      _documentsFuture = Future.value([]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.employeeId != null
            ? 'Employee Documents'
            : 'My Submitted Documents'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: _searchDocuments,
          ),
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: _filterDocuments,
          ),
        ],
      ),
      body: FutureBuilder<List<DocumentUpload>>(
          future: _documentsFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return _buildEmptyState();
            }

            _documents = snapshot.data!;

            return Column(
              children: [
                _buildStatsCard(),
                Expanded(child: _buildDocumentsList()),
              ],
            );
          }),
    );
  }

  Widget _buildStatsCard() {
    final verifiedCount = _documents
        .where((doc) => doc.status == 'verified')
        .length;
    final pendingCount = _documents
        .where((doc) => doc.status == 'under_review')
        .length;
    final totalCount = _documents.length;

    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStatItem('Total', totalCount.toString(), Colors.blue),
            _buildStatItem('Verified', verifiedCount.toString(), Colors.green),
            _buildStatItem('Pending', pendingCount.toString(), Colors.orange),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_off_outlined, size: 80, color: Colors.grey),
          SizedBox(height: 16),
          Text(
            'No documents found',
            style: TextStyle(fontSize: 18, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentsList() {
    if (_documents.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: _documents.length,
      itemBuilder: (context, index) {
        return _buildDocumentCard(_documents[index]);
      },
    );
  }

  Widget _buildDocumentCard(DocumentUpload document) {
    Color statusColor;
    String statusText;

    switch (document.status) {
      case 'verified':
        statusColor = Colors.green;
        statusText = 'Verified';
        break;
      case 'rejected':
        statusColor = Colors.red;
        statusText = 'Rejected';
        break;
      case 'under_review':
        statusColor = Colors.orange;
        statusText = 'Under Review';
        break;
      default:
        statusColor = Colors.blue;
        statusText = 'Uploaded';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => _viewDocument(document),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  document.documentIcon,
                  size: 30,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      document.documentTypeName,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      document.fileName,
                      style: const TextStyle(color: Colors.grey, fontSize: 14),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          document.fileSize,
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text('•', style: TextStyle(color: Colors.grey[400])),
                        const SizedBox(width: 8),
                        Text(
                          '${document.uploadDate.day}/${document.uploadDate.month}/${document.uploadDate.year}',
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      statusText,
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  IconButton(
                    icon: const Icon(Icons.visibility, size: 20),
                    onPressed: () => _viewDocument(document),
                    tooltip: 'View Document',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAdminActions(DocumentUpload document) {
    // Only show actions if in admin view
    if (widget.employeeId == null) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () {}, // TODO: Implement approve logic
              icon: const Icon(Icons.check, size: 16),
              label: const Text('Approve'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () {}, // TODO: Implement reject logic
              icon: const Icon(Icons.close, size: 16),
              label: const Text('Reject'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  void _viewDocument(DocumentUpload document) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DocumentViewerScreen(document: document),
              ),
    );}

  void _searchDocuments() {
    showSearch(context: context, delegate: DocumentSearchDelegate(_documents));
  }

  void _filterDocuments() {
    showModalBottomSheet(
      context: context,
      builder: (context) => _buildFilterBottomSheet(),
    );
  }

  Widget _buildFilterBottomSheet() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Filter Documents',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          _buildFilterOption('All Documents', Icons.all_inclusive),
          _buildFilterOption(
            'Verified Only',
            Icons.verified,
            color: Colors.green,
          ),
          _buildFilterOption(
            'Pending Review',
            Icons.pending,
            color: Colors.orange,
          ),
          _buildFilterOption(
            'ID Documents',
            Icons.credit_card,
            color: Colors.blue,
          ),
          _buildFilterOption(
            'Employment Proof',
            Icons.work,
            color: Colors.purple,
          ),
          _buildFilterOption('Selfie Photos', Icons.face, color: Colors.orange),
        ],
      ),
    );
  }

  Widget _buildFilterOption(
    String title,
    IconData icon, {
    Color color = Colors.grey,
  }) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        // Implement filter logic here
      },
    );
  }
}

class DocumentSearchDelegate extends SearchDelegate {
  final List<DocumentUpload> documents;

  DocumentSearchDelegate(this.documents);

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return _buildSearchResults();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return _buildSearchResults();
  }

  Widget _buildSearchResults() {
    final results = documents
        .where(
          (doc) =>
              doc.documentTypeName.toLowerCase().contains(
                query.toLowerCase(),
              ) ||
              doc.fileName.toLowerCase().contains(query.toLowerCase()),
        )
        .toList();

    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (context, index) {
        final document = results[index];
        return ListTile(
          leading: Icon(document.documentIcon),
          title: Text(document.documentTypeName),
          subtitle: Text(document.fileName),
          trailing: Text(
            '${document.uploadDate.day}/${document.uploadDate.month}/${document.uploadDate.year}',
          ),
          onTap: () {
            close(context, null);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DocumentViewerScreen(document: document),
              ),
            );
          },
        );
      },
    );
  }
}
